package VarlableExam.src.Subway;

public class Subway {
	
	public void Info() {}
	public void Info(int i) {}
	
	public static void main(String [] args) {
		kiosk.kio();//Ű����ũ ���� ȭ��
		System.out.println(burger.AllPrice);
	}

}
